# zram_fiori
Ram Project for ABAP RAP to explain FIori element series
